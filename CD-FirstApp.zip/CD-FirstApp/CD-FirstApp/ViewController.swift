//
//  ViewController.swift
//  CD-FirstApp
//
//  Created by Tanya Atrvash on 9/6/24.
//

import UIKit

class ViewController: UIViewController, UITextFieldDelegate {
    
    // outlets conventionally are placed here
    @IBOutlet weak var textField: UITextField!
    @IBOutlet weak var statusLabel: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        textField.delegate = self
    }

    // actions conventionally are placed here
    @IBAction func buttonPressed(_ sender: Any) {
        // get the string that the user typed into the text field
        let name = textField.text!
        
        // append the string "pressed the button" to the string
        let message = name + " pressed the button"
        
        // put the result into the status label
        statusLabel.text = message
    }
    
    // Called when 'return' key pressed

     func textFieldShouldReturn(_ textField:UITextField) -> Bool {
         textField.resignFirstResponder()
         return true
     }
     
     // Called when the user clicks on the view outside of the UITextField

     override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
         self.view.endEditing(true)
     }
    
}

