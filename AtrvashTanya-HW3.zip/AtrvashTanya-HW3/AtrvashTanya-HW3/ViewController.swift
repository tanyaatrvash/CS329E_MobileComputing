// Project: AtrvashTanya-HW3
// EID: tka435
// Course: CS329E

//  ViewController.swift
//  AtrvashTanya-HW3
//
//  Created by Tanya Atrvash on 9/23/24.
//

import UIKit

// passing the updated text back
protocol TextChangeDelegate {
    func updateText(_ newText: String)
}

// passing the updated background color back
protocol ColorChangeDelegate {
    func updateColor(_ newColor: UIColor)
}

class ViewController: UIViewController, ColorChangeDelegate, TextChangeDelegate {

    @IBOutlet weak var textFieldVC1: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
    }
    
    // preparing segue to pass data to the other VCs
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // if text segue is triggered
        if segue.identifier == "SegueIdentifierText" {
            if let textVC = segue.destination as? SecondViewController {
                textVC.delegate = self
                textVC.vc2NewName = textFieldVC1.text!
            }
            // if color segue is triggered
        } else if segue.identifier == "SegueIdentifierColor" {
            if let colorVC = segue.destination as? ThirdViewController {
                colorVC.delegate = self
            }
        }
    }
    
    // update label text
    func updateText(_ newText: String) {
        textFieldVC1.text = newText
    }
    
    // update label color
    func updateColor(_ newColor: UIColor) {
        textFieldVC1.backgroundColor = newColor
    }

}

