// Project: AtrvashTanya-HW3
// EID: tka435
// Course: CS329E

//  SecondViewController.swift
//  AtrvashTanya-HW3
//
//  Created by Tanya Atrvash on 9/24/24.
//

import UIKit

class SecondViewController: UIViewController {
    
    @IBOutlet weak var textFieldVC2: UITextField!
    
    var delegate: TextChangeDelegate?
    var currentText: String?
    var vc2NewName = ""
    
    override func viewDidLoad() {
        super.viewDidLoad()
        textFieldVC2.text = vc2NewName
    }
    
    @IBAction func saveButton2Pressed(_ sender: Any) {
        // pass updated text back to main VC via delegate
        if let newText = textFieldVC2.text {
            delegate?.updateText(newText)
        }
        
        
    }
}
