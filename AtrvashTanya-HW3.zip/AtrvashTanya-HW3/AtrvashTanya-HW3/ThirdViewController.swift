// Project: AtrvashTanya-HW3
// EID: tka435
// Course: CS329E

//  ThirdViewController.swift
//  AtrvashTanya-HW3
//
//  Created by Tanya Atrvash on 9/24/24.
//

import UIKit

class ThirdViewController: UIViewController {
    
    var delegate: ColorChangeDelegate?

    override func viewDidLoad() {
        super.viewDidLoad()
    }
    

    @IBAction func blueButtonPressed(_ sender: Any) {
        delegate?.updateColor(.blue)
    }
    
    @IBAction func redButtonPressed(_ sender: Any) {
        delegate?.updateColor(.red)
    }
}
