README
Project Name: AccessAble
Description:
AccessAble is a SwiftUI app designed to allow users to find accessible venues in their area. Users are able to sign up/log into the app using Firebase authentication, profile management and settings, and add venues to their favorites list to be able to look at later. 


Dependencies:
- Xcode Version: 16.0 or later
- Packages/Pods:
	- Firebase SDK (Authentication and Firestore): install using Swift Package Manager or Cocoapods
	- Firebase configuration file GoogleService-Info.plist already located in zip file

Instructions to Test the App:
- Simulator: iPhone 16 Pro or any equivalent device with iOS 18. Portrait mode is required; landscape mode is not supported.
- Test Account:
	- Email: tanya@gmail.com
	- Password: test123

Notes on Testing:
- To fully experience the app, create a new account using the Sign Up screen.

Known Bug:
- Occasionally, after logging in, the navigation bar at the bottom of the app may not appear.
- Solution: Kill the app and reopen it. Upon reopening, you will remain logged in, and the navigation bar will appear as expected.

Checklist:
- Required Features:
	- Settings Screen: The two behaviors implemented are: theme customization (font and color changes) and account logout functionality.
	- Non-default Fonts and Colors: custom font styles for the main titles (font: AvenirNext-Bold) and dynamic color themes for the light and dark modes.
	- Login/Register Path with Firebase: implemented using Firebase Authentication for secure user login and registration.
	- Multithreading: utilized for handling Firebase data requests and image processing without blocking the main thread.
	- SwiftUI: the entire app is built using SwiftUI for declarative UI programming.

- Minor Features:
Two Additional View Types:
	- Segmented Controllers: used in the settings screen for theme selection.
	- View Controllers:
		- Tab View Controller: used for the app's main navigation structure.
- Other Elements:
	- Alerts: used in profile settings (such as choosing light/dark mode), leaving reviews, and shown for errors like incorrect login credentials.
	- Scroll Views: implemented for vertically scrolling content in the map view of city.

- Additional Features:
	- MapKit: implemented to show maps and accessibility features at places of interest.
	- Animation: smooth transitions between screens and elements.

Future Adaptations:
To enhance the functionality of AccessAble, I plan to implement the following adaptations:
- API Integration for Accessibility Information:
Replace the hardcoded list of venues with an API that provides real-time data about places and their accessibility features. This will allow the app to dynamically fetch and display relevant information based on user queries. The API will help expand the database to include a wider range of places and cities around the globe.

- Global Expansion:
Currently limited to Austin, Texas, I aim to expand the app’s functionality to include cities worldwide. This will make AccessAble a truly global solution for users seeking accessible places and services regardless of their location.

- Enhanced UI/UX:
I am working on a more refined and intuitive user interface that aligns with modern design standards. This includes improving the overall aesthetics, interaction flows, and usability of the app to provide a more seamless user experience across all platforms.

- Overall Finetuning:
This application is very rudimentary and needs tweaking to be able to be used by the public. I plan to use this winter break to continue working on AccessAble with my free time, clearing the app of any bugs in the logic, improving the interface, and adding additional features such as photos of the venues (using an API), implementing profile photo functionality using the camera or photo library, and more.