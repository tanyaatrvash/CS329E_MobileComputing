// AccessAble_AtrvashTanya
// UT EID: tka435
// CS329E

//  SceneDelegate.swift
//  AccessAble
//
//  Created by Tanya Atrvash on 12/9/24.
//


import UIKit
import SwiftUI
import FirebaseAuth

class SceneDelegate: UIResponder, UIWindowSceneDelegate {
    var window: UIWindow?
    let appState = AppState()

    func scene(_ scene: UIScene, willConnectTo session: UISceneSession, options connectionOptions: UIScene.ConnectionOptions) {
        guard let windowScene = (scene as? UIWindowScene) else { return }
        
        let window = UIWindow(windowScene: windowScene)
        window.rootViewController = UIHostingController(rootView: ContentView()
            .environmentObject(appState))
        
        self.window = window
        window.makeKeyAndVisible()
    }
}
