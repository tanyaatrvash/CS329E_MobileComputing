// AccessAble_AtrvashTanya
// UT EID: tka435
// CS329E

//  AppState.swift
//  AccessAble
//
//  Created by Tanya Atrvash on 12/8/24.
//


import Foundation
import FirebaseAuth

class AppState: ObservableObject {
    @Published var isUserLoggedIn: Bool = false

    init() {
        // check if the user is already logged in when the app starts
        self.isUserLoggedIn = Auth.auth().currentUser != nil
    }

    func logIn() {
        self.isUserLoggedIn = true
    }

    func logOut() {
        do {
            try Auth.auth().signOut()
            self.isUserLoggedIn = false
        } catch {
            print("Error logging out: \(error.localizedDescription)")
        }
    }
}
