// AccessAble_AtrvashTanya
// UT EID: tka435
// CS329E

//  FavoritesManager.swift
//  AccessAble
//
//  Created by Tanya Atrvash on 12/9/24.
//

import Foundation
import Combine

class FavoritesManager: ObservableObject {
    @Published var favorites: [Venue] = []

    func isFavorited(_ venue: Venue) -> Bool {
        favorites.contains(where: { $0.id == venue.id })
    }

    func addToFavorites(_ venue: Venue) {
        favorites.append(venue)
    }

    func removeFromFavorites(_ venue: Venue) {
        favorites.removeAll(where: { $0.id == venue.id })
    }
}

