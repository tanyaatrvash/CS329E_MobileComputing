// AccessAble_AtrvashTanya
// UT EID: tka435
// CS329E

//  VenueDetailsView.swift
//  AccessAble
//
//  Created by Tanya Atrvash on 12/8/24.
//


import SwiftUI

struct VenueDetailsView: View {
    @EnvironmentObject var favoritesManager: FavoritesManager
    
    let venue: Venue
    
    @State private var showAlert = false
    @State private var rating: Int = 3
    @State private var reviewText: String = ""
    @State private var selectedFeatures: String = ""

    var body: some View {
        VStack(alignment: .leading, spacing: 20) {
            HStack {
                Text(venue.name)
                    .font(.largeTitle)
                    .padding(.top)
                Spacer()
                Button(action: {
                    if favoritesManager.isFavorited(venue) {
                        favoritesManager.removeFromFavorites(venue)
                    } else {
                        favoritesManager.addToFavorites(venue)
                    }
                }) {
                    Image(systemName: favoritesManager.isFavorited(venue) ? "heart.fill" : "heart")
                        .resizable()
                        .frame(width: 24, height: 24)
                        .foregroundColor(favoritesManager.isFavorited(venue) ? .red : .gray)
                }
                .padding()
            }

            Text(venue.address)
                .font(.subheadline)
                .padding()

            Section(header: Text("Accessibility Features")) {
                Text(venue.features)
                    .font(.footnote)
                    .foregroundColor(.gray)
            }

            Section(header: Text("Reviews")) {
                Text("Great place, accessible and cozy!")
                Text("Friendly staff and good food. Accessible parking available.")
            }

            Spacer()

            Button(action: {
                showAlert.toggle()
            }) {
                Text("Add Review")
                    .padding()
                    .background(Color.blue)
                    .foregroundColor(.white)
                    .cornerRadius(8)
            }
            .alert("Add Review for \(venue.name)", isPresented: $showAlert, actions: {
                Picker("Rating", selection: $rating) {
                    ForEach(1..<6) { index in
                        Text("\(index)").tag(index)
                    }
                }
                
                TextField("Write your review...", text: $reviewText)
                
                Picker("Accessibility Features", selection: $selectedFeatures) {
                    Text("Wheelchair accessible").tag("Wheelchair accessible")
                    Text("Accessible parking").tag("Accessible parking")
                    Text("ADA-compliant entrance").tag("ADA-compliant entrance")
                    Text("Gender-neutral restrooms").tag("Gender-neutral restrooms")
                }
                
                Button("Save", action: saveReview)
                Button("Cancel", role: .cancel, action: {})
            }, message: {
                Text("Please share your experience and rate the venue")
            })
        }
        .navigationTitle(venue.name)
    }

    private func saveReview() {
        print("Review saved for \(venue.name): \(rating) stars, \(reviewText), Features: \(selectedFeatures)")
        
        rating = 3
        reviewText = ""
        selectedFeatures = ""
    }
}


