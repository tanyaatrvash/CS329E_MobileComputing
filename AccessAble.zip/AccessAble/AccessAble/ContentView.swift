// AccessAble_AtrvashTanya
// UT EID: tka435
// CS329E

//  ContentView.swift
//  AccessAble
//
//  Created by Tanya Atrvash on 12/8/24.
//

import SwiftUI
import FirebaseAuth

struct ContentView: View {
    @StateObject private var appState = AppState()
    @StateObject private var favoritesManager = FavoritesManager()

    var body: some View {
        NavigationView {
            Group {
                if appState.isUserLoggedIn {
                    // main TabView for logged-in users
                    TabView {
                        NavigationView {
                            HomeView()
                        }
                        .tabItem {
                            Label("Home", systemImage: "house.fill")
                        }

                        NavigationView {
                            ProfileViewWrapper()
                                .navigationTitle("Profile")
                                .font(.custom("AvenirNext-Bold", size: 24))
                        }
                        .tabItem {
                            Label("Me", systemImage: "person.fill")
                        }

                        NavigationView {
                            FavoritesViewWrapper()
                                .navigationTitle("Favorites")
                                .font(.custom("AvenirNext-Bold", size: 24))
                        }
                        .tabItem {
                            Label("Favorites", systemImage: "heart.fill")
                        }
                    }
                    .environmentObject(favoritesManager)
                } else {
                    // welcome screen for non-logged-in users
                    VStack(spacing: 20) {
                        Text("AccessAble")
                            .font(.custom("AvenirNext-Bold", size: 24))
                            .fontWeight(.bold)

                        NavigationLink(destination: LoginView(appState: appState)) {
                            Text("Login")
                                .padding()
                                .frame(maxWidth: .infinity)
                                .background(Color.blue)
                                .foregroundColor(.white)
                                .cornerRadius(8)
                        }

                        NavigationLink(destination: SignUpView()) {
                            Text("Sign Up")
                                .padding()
                                .frame(maxWidth: .infinity)
                                .background(Color.green)
                                .foregroundColor(.white)
                                .cornerRadius(8)
                        }
                    }
                    .padding()
                    .navigationTitle("Welcome")
                    .font(.custom("AvenirNext-Bold", size: 24))
                }
            }
        }
        .environmentObject(appState)
        .onAppear {
            if appState.isUserLoggedIn {
            }
        }
    }
}

#Preview {
    ContentView()
}
