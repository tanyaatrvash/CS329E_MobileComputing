// AccessAble_AtrvashTanya
// UT EID: tka435
// CS329E

//  AddReviewView.swift
//  AccessAble
//
//  Created by Tanya Atrvash on 12/8/24.
//


import SwiftUI

struct AddReviewView: View {
    @State private var rating = 3.0
    @State private var reviewText = ""

    var body: some View {
        VStack {
            Text("Add Review")
                .font(.title)
                .fontWeight(.bold)

            Slider(value: $rating, in: 0...5, step: 0.5) {
                Text("Rating")
            }
            .padding()

            TextField("Write your review here...", text: $reviewText)
                .padding()
                .background(Color.gray.opacity(0.2))
                .cornerRadius(8)

            Button(action: submitReview) {
                Text("Submit Review")
                    .padding()
                    .frame(maxWidth: .infinity)
                    .background(Color.green)
                    .foregroundColor(.white)
                    .cornerRadius(8)
            }
        }
        .padding()
    }

    private func submitReview() {

    }
}
