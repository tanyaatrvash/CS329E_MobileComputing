// AccessAble_AtrvashTanya
// UT EID: tka435
// CS329E

//  HomeView.swift
//  AccessAble
//
//  Created by Tanya Atrvash on 12/8/24.
//


import SwiftUI
import MapKit

struct Venue: Identifiable {
    let id = UUID()
    let name: String
    let address: String
    let type: String
    let features: String
    let latitude: Double
    let longitude: Double
}

struct HomeView: View {
    @State private var searchText = ""
    @State private var isMapView = true
    @State private var cameraPosition = MapCameraPosition.region(
        MKCoordinateRegion(
            center: CLLocationCoordinate2D(latitude: 30.2672, longitude: -97.7431), // default Austin, TX
            span: MKCoordinateSpan(latitudeDelta: 0.1, longitudeDelta: 0.1)
        )
    )
    @State private var venues = [ // hard-coded list of venues; implement API for better usage later
        Venue(name: "The Vortex",
            address: "2307 Manor Rd, Austin, TX 78722",
            type: "Entertainment",
            features: "Wheelchair accessible",
            latitude: 30.284389,
            longitude: -97.717697),
        Venue(name: "Tiki 311",
            address: "311 E 6th St, Austin, TX 78701",
            type: "Bar",
            features: "Wheelchair accessible",
            latitude: 30.267037,
            longitude: -97.739967),
        Venue(name: "Simona's",
            address: "2510 S Congress Ave, Colton House Hotel, Austin, TX 78704",
            type: "Bar",
            features: "Wheelchair accesible, accessible parking, ADA-compliant entrance, ADA-compliant restrooms, gender-neutral restrooms",
            latitude: 30.237204,
            longitude: -97.755088),
        Venue(name: "Loro Asian Smokehouse and Bar",
            address: "2115 S Lamar Blvd, Austin, TX 78704",
            type: "Restaurant",
            features: "Wheelchair accesible, accessible parking, ADA-compliant entrance",
            latitude: 30.247749,
            longitude: -97.771278),
        Venue(name: "Dear Austin Coffee Bar",
            address: "2310 S Lamar Blvd, Unit 102, Austin, TX 78704",
            type: "Coffee Shop",
            features: "Wheelchair accessible",
            latitude: 30.247511,
            longitude: -97.775028),
        Venue(name: "True Food Kitchen",
            address: "222 W Ave, Ste HR100, Austin, TX 78701",
            type: "Restaurant",
            features: "Wheelchair accessible, ADA-compliant entrance",
            latitude: 30.2669687,
            longitude: -97.7523979),
        Venue(name: "Aba",
            address: "1011 S Congress Ave, Bldg 2, Ste 180, Austin, TX 78704",
            type: "Restaurant",
            features: "Wheelchair accessible, ADA-compliant entrance, vegan options, vegetarian options, gender-neutral restrooms",
            latitude: 30.255792,
            longitude: -97.747311),
        Venue(name: "Hi Tunes Karaoke",
            address: "911 W Anderson Ln, Ste 117, Austin, TX 78757",
            type: "Entertainment",
            features: "Wheelchair accessible",
            latitude: 30.348133,
            longitude: -97.714839),
        Venue(name: "Antone's Nightclub",
            address: "305 E 5th, Austin, TX 78701",
            type: "Entertainment",
            features: "Wheelchair accessible",
            latitude: 30.266353,
            longitude: -97.74072),
        Venue(name: "Merfolk's Specialty Coffee",
            address: "4930 S Congress Ave, Ste 304C, Austin, TX 78745",
            type: "Coffee Shop",
            features: "Wheelchair accesible, accessible parking, ADA-compliant entrance, ADA-compliant restrooms, gender-neutral restrooms",
            latitude: 30.212939,
            longitude: -97.771002)
    ]

    @State private var showingAddVenueAlert = false
    @State private var newVenueName = ""
    @State private var newVenueAddress = ""
    @State private var newVenueFeature = "Wheelchair accessible"
    @State private var selectedVenueFeatures = ["Wheelchair accessible"]
    @State private var newVenueLatitude: Double = 0.0
    @State private var newVenueLongitude: Double = 0.0


    private let venueFeatures = [
        "Wheelchair accessible",
        "Accessible parking",
        "ADA-compliant entrance",
        "ADA-compliant restrooms",
        "Gender-neutral restrooms",
        "Other"
    ]

    var body: some View {
        NavigationView {
            VStack {
                TextField("Search for venues", text: $searchText)
                    .padding()
                    .background(Color.gray.opacity(0.2))
                    .cornerRadius(8)
                    .padding(.horizontal)

                HStack {
                    Button(action: {
                        isMapView.toggle()
                    }) {
                        Text(isMapView ? "View List" : "View Map")
                            .padding()
                            .background(Color.blue)
                            .foregroundColor(.white)
                            .cornerRadius(8)
                    }

                    Spacer()

                    Button(action: {
                        showingAddVenueAlert = true
                    }) {
                        Image(systemName: "plus")
                            .padding()
                            .background(Color.green)
                            .foregroundColor(.white)
                            .cornerRadius(8)
                    }
                }
                .padding(.horizontal)

                if isMapView {
                    Map(position: $cameraPosition) {
                        ForEach(venues) { venue in
                            Marker(venue.name, coordinate: CLLocationCoordinate2D(latitude: venue.latitude, longitude: venue.longitude))
                        }
                    }
                    .ignoresSafeArea(edges: .all)

                } else {
                    List(venues.filter { searchText.isEmpty || $0.name.contains(searchText) }) { venue in
                        NavigationLink(destination: VenueDetailsView(venue: venue)) {
                            VStack(alignment: .leading) {
                                Text(venue.name)
                                    .font(.headline)
                                Text(venue.address)
                                    .font(.subheadline)
                                Text("Features: \(venue.features)")
                                    .font(.footnote)
                                    .foregroundColor(.gray)
                            }
                        }
                    }
                }
            }
            .navigationTitle("Home")
            .alert("Add Venue", isPresented: $showingAddVenueAlert, actions: {
                TextField("Venue Name", text: $newVenueName)
                TextField("Address", text: $newVenueAddress)
                Picker("Features", selection: $newVenueFeature) {
                    ForEach(venueFeatures, id: \.self) { feature in
                        Text(feature)
                    }
                }
                Button("Add", action: addVenue)
                Button("Cancel", role: .cancel, action: {})
            }, message: {
                Text("Enter venue details below.")
            })
        }
    }

    private func addVenue() {
        let newVenue = Venue(
            name: newVenueName,
            address: newVenueAddress,
            type: "Custom",
            features: newVenueFeature,
            latitude: newVenueLatitude,
            longitude: newVenueLongitude
        )
        venues.append(newVenue)
        newVenueName = ""
        newVenueAddress = ""
        newVenueFeature = venueFeatures[0]
        newVenueLatitude = 0.0
        newVenueLongitude = 0.0
    }
    
    private func navigationLinkToVenue(_ venue: Venue) -> some View {
        NavigationLink(destination: VenueDetailsView(venue: venue)) {

        }
        .buttonStyle(PlainButtonStyle()) 
    }

}
