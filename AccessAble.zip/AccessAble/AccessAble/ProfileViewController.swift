// AccessAble_AtrvashTanya
// UT EID: tka435
// CS329E

//  ProfileViewController.swift
//  AccessAble
//
//  Created by Tanya Atrvash on 12/8/24.
//


import UIKit
import SwiftUI
import FirebaseAuth

struct ProfileViewWrapper: View {
    var body: some View {
        ProfileUIKitView()
    }
}

struct ProfileUIKitView: UIViewControllerRepresentable {
    func makeUIViewController(context: Context) -> ProfileViewController {
        return ProfileViewController()
    }
    
    func updateUIViewController(_ uiViewController: ProfileViewController, context: Context) {
    }
}

class ProfileViewController: UIViewController {
    
    private let usernameLabel = UILabel()
    private let profileImageView = UIImageView()
    private let profileSettingsButton = UIButton()
    private let myAccessButton = UIButton()
    private let logoutButton = UIButton()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        setupView()
        setupConstraints()
        fetchUserProfile()
    }
    
    private func setupView() {
        usernameLabel.textAlignment = .center
        usernameLabel.font = UIFont.boldSystemFont(ofSize: 20)
        view.addSubview(usernameLabel)
        
        profileImageView.contentMode = .scaleAspectFill
        profileImageView.clipsToBounds = true
        profileImageView.layer.cornerRadius = 50
        view.addSubview(profileImageView)
        
        profileSettingsButton.setTitle("Profile Settings", for: .normal)
        profileSettingsButton.backgroundColor = .blue
        profileSettingsButton.addTarget(self, action: #selector(navigateToSettings), for: .touchUpInside)
        view.addSubview(profileSettingsButton)
        
        myAccessButton.setTitle("My Access", for: .normal)
        myAccessButton.backgroundColor = .green
        myAccessButton.addTarget(self, action: #selector(navigateToAccess), for: .touchUpInside)
        view.addSubview(myAccessButton)
        
        logoutButton.setTitle("Log Out", for: .normal)
        logoutButton.backgroundColor = .red
        logoutButton.addTarget(self, action: #selector(promptLogout), for: .touchUpInside)
        view.addSubview(logoutButton)
    }
    
    private func setupConstraints() {
        usernameLabel.translatesAutoresizingMaskIntoConstraints = false
        profileImageView.translatesAutoresizingMaskIntoConstraints = false
        profileSettingsButton.translatesAutoresizingMaskIntoConstraints = false
        myAccessButton.translatesAutoresizingMaskIntoConstraints = false
        logoutButton.translatesAutoresizingMaskIntoConstraints = false
        
        NSLayoutConstraint.activate([
            // Username Label Constraints
            usernameLabel.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor, constant: 50),
            usernameLabel.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            
            // Profile Image Constraints
            profileImageView.topAnchor.constraint(equalTo: usernameLabel.bottomAnchor, constant: 20),
            profileImageView.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            profileImageView.widthAnchor.constraint(equalToConstant: 100),
            profileImageView.heightAnchor.constraint(equalToConstant: 100),
            
            // Profile Settings Button Constraints
            profileSettingsButton.topAnchor.constraint(equalTo: profileImageView.bottomAnchor, constant: 20),
            profileSettingsButton.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            profileSettingsButton.widthAnchor.constraint(equalToConstant: 200),
            profileSettingsButton.heightAnchor.constraint(equalToConstant: 44),
            
            // My Access Button Constraints
            myAccessButton.topAnchor.constraint(equalTo: profileSettingsButton.bottomAnchor, constant: 20),
            myAccessButton.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            myAccessButton.widthAnchor.constraint(equalToConstant: 200),
            myAccessButton.heightAnchor.constraint(equalToConstant: 44),
            
            // Logout Button Constraints
            logoutButton.topAnchor.constraint(equalTo: myAccessButton.bottomAnchor, constant: 20),
            logoutButton.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            logoutButton.widthAnchor.constraint(equalToConstant: 200),
            logoutButton.heightAnchor.constraint(equalToConstant: 44)
        ])
    }
    
    private func fetchUserProfile() {
        // get current user from firebase
        guard let user = Auth.auth().currentUser else {
            usernameLabel.text = "No user logged in"
            return
        }
        
        let email = user.email ?? "No email available"
        usernameLabel.text = email
    }
    
    @objc private func navigateToSettings() {
        let settingsVC = SettingsViewController()
        navigationController?.pushViewController(settingsVC, animated: true)
    }
    
    @objc private func navigateToAccess() {
        let accessVC = MyAccessViewController()
        navigationController?.pushViewController(accessVC, animated: true)
    }
    
    @objc private func promptLogout() {
        let alertController = UIAlertController(title: "Logout", message: "Are you sure you want to log out?", preferredStyle: .alert)
        let cancelAction = UIAlertAction(title: "No", style: .cancel, handler: nil)
        let logoutAction = UIAlertAction(title: "Yes", style: .destructive) { _ in
            self.logoutUser()
        }
        alertController.addAction(cancelAction)
        alertController.addAction(logoutAction)
        present(alertController, animated: true, completion: nil)
    }
    
    @objc private func logoutUser() {
        do {
            try Auth.auth().signOut()
            if let windowScene = UIApplication.shared.connectedScenes.first as? UIWindowScene,
               let sceneDelegate = windowScene.delegate as? SceneDelegate {
                sceneDelegate.appState.isUserLoggedIn = false
            }
        } catch let signOutError as NSError {
            print("Error signing out: %@", signOutError)
            return
        }
    }
}
