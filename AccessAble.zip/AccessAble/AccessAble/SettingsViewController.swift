// AccessAble_AtrvashTanya
// UT EID: tka435
// CS329E

//  SettingsViewController.swift
//  AccessAble
//
//  Created by Tanya Atrvash on 12/8/24.
//


import UIKit

class SettingsViewController: UIViewController, UITableViewDataSource, UITableViewDelegate {
    
    private let tableView = UITableView()
    private let settingsOptions = ["Light/Dark Mode", "Notification Preferences", "Location Settings"]
    
    override func viewDidLoad() {
        super.viewDidLoad()
        setupView()
        setupConstraints()
    }
    
    private func setupView() {
        view.backgroundColor = .systemBackground
        title = "Settings"
        
        tableView.dataSource = self
        tableView.delegate = self
        tableView.register(UITableViewCell.self, forCellReuseIdentifier: "settingsCell")
        view.addSubview(tableView)
    }
    
    private func setupConstraints() {
        tableView.translatesAutoresizingMaskIntoConstraints = false
        NSLayoutConstraint.activate([
            tableView.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor),
            tableView.leftAnchor.constraint(equalTo: view.leftAnchor),
            tableView.rightAnchor.constraint(equalTo: view.rightAnchor),
            tableView.bottomAnchor.constraint(equalTo: view.bottomAnchor)
        ])
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return settingsOptions.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "settingsCell", for: indexPath)
        cell.textLabel?.text = settingsOptions[indexPath.row]
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        tableView.deselectRow(at: indexPath, animated: true)
        
        switch indexPath.row {
        case 0:
            showLightDarkModeAlert()
        case 1:
            showNotificationPreferencesAlert()
        case 2:
            showLocationSettingsAlert()
        default:
            break
        }
    }
}


// light/dark mode
extension SettingsViewController {
    private func showLightDarkModeAlert() {
        let alertController = UIAlertController(
            title: "Choose Theme",
            message: "Select your preferred theme.",
            preferredStyle: .alert
        )
        
        alertController.addAction(UIAlertAction(title: "Light Mode", style: .default) { _ in
            self.setTheme(.light)
        })
        
        alertController.addAction(UIAlertAction(title: "Dark Mode", style: .default) { _ in
            self.setTheme(.dark)
        })
        
        alertController.addAction(UIAlertAction(title: "Cancel", style: .cancel))
        present(alertController, animated: true)
    }
    
    private func setTheme(_ theme: UIUserInterfaceStyle) {
        guard let windowScene = UIApplication.shared.connectedScenes.first as? UIWindowScene,
              let window = windowScene.windows.first else {
            return
        }
        window.overrideUserInterfaceStyle = theme
        showNotificationAlert(message: theme == .light ? "Switched to Light Mode" : "Switched to Dark Mode")
    }

}



// notif preferences
extension SettingsViewController {
    private func showNotificationPreferencesAlert() {
        let alertController = UIAlertController(
            title: "Notification Preferences",
            message: "Select your notification style.",
            preferredStyle: .alert
        )
        
        alertController.addAction(UIAlertAction(title: "Full-Screen Alerts", style: .default) { _ in
            UserDefaults.standard.set("Full-Screen Alerts", forKey: "NotificationStyle")
            self.showNotificationAlert(message: "Notification style set to Full-Screen Alerts")
        })
        
        alertController.addAction(UIAlertAction(title: "Banners", style: .default) { _ in
            UserDefaults.standard.set("Banners", forKey: "NotificationStyle")
            self.showNotificationAlert(message: "Notification style set to Banners")
        })
        
        alertController.addAction(UIAlertAction(title: "Cancel", style: .cancel))
        present(alertController, animated: true)
    }
    
    private func showNotificationAlert(message: String) {
        let notificationStyle = UserDefaults.standard.string(forKey: "NotificationStyle") ?? "Banners"
        if notificationStyle == "Full-Screen Alerts" {
            let alert = UIAlertController(title: "Notification", message: message, preferredStyle: .alert)
            alert.addAction(UIAlertAction(title: "OK", style: .default))
            present(alert, animated: true)
        } else {
            let banner = UILabel()
            banner.text = message
            banner.backgroundColor = .systemGray
            banner.textColor = .white
            banner.textAlignment = .center
            banner.frame = CGRect(x: 0, y: 0, width: view.frame.width, height: 50)
            view.addSubview(banner)
            
            UIView.animate(withDuration: 2.0, animations: {
                banner.frame.origin.y += 50
            }, completion: { _ in
                banner.removeFromSuperview()
            })
        }
    }
}



// location settings
extension SettingsViewController {
    private func showLocationSettingsAlert() {
        let alertController = UIAlertController(
            title: "Update Location",
            message: "Enter your city and state.",
            preferredStyle: .alert
        )
        
        alertController.addTextField { textField in
            textField.placeholder = "City"
        }
        
        alertController.addTextField { textField in
            textField.placeholder = "State"
        }
        
        alertController.addAction(UIAlertAction(title: "Update", style: .default) { _ in
            if let city = alertController.textFields?[0].text,
               let state = alertController.textFields?[1].text,
               !city.isEmpty,
               !state.isEmpty {
                self.updateLocation(city: city, state: state)
            }
        })
        
        alertController.addAction(UIAlertAction(title: "Cancel", style: .cancel))
        present(alertController, animated: true)
    }
    
    private func updateLocation(city: String, state: String) {
        UserDefaults.standard.set("\(city), \(state)", forKey: "UserLocation")
        showNotificationAlert(message: "Location updated to \(city), \(state)")
        
        NotificationCenter.default.post(name: Notification.Name("LocationUpdated"), object: nil)
    }
}

