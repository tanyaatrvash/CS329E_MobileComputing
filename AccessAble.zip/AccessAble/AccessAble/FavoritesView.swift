// AccessAble_AtrvashTanya
// UT EID: tka435
// CS329E

//  FavoritesView.swift
//  AccessAble
//
//  Created by Tanya Atrvash on 12/9/24.
//

import SwiftUI

struct FavoritesViewWrapper: View {
    var body: some View {
        FavoritesView()
    }
}

struct FavoritesView: View {
    @EnvironmentObject var favoritesManager: FavoritesManager

    var body: some View {
        List(favoritesManager.favorites) { venue in
            NavigationLink(destination: VenueDetailsView(venue: venue)) {
                VStack(alignment: .leading) {
                    Text(venue.name)
                        .font(.headline)
                    Text(venue.address)
                        .font(.subheadline)
                }
            }
        }
        .navigationTitle("Favorites")
        .listStyle(InsetGroupedListStyle())
    }
}
