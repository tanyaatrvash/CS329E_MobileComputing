// Project: AtrvashTanya-HW5
// EID: tka435
// Course: CS329E

//  ViewController.swift
//  AtrvashTanya-HW5
//
//  Created by Tanya Atrvash on 10/14/24.
//

import UIKit

// pizza list to store created pizzas
var pizzaList: [Pizza] = []

class ViewController: UIViewController,UITableViewDelegate, UITableViewDataSource, PizzaCreationDelegate {
    
    @IBOutlet weak var tableView: UITableView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // nav bar & + button
        navigationItem.rightBarButtonItem = UIBarButtonItem(barButtonSystemItem: .add, target: self, action: #selector(addPizzaButtonPressed))
        
        // setting back button to "Pizza Order"
        let backButton = UIBarButtonItem()
        backButton.title = "Pizza Order"
        navigationItem.backBarButtonItem = backButton
        
        // set up table view
        tableView.delegate = self
        tableView.dataSource = self
}
    
    // action for + button
    @objc func addPizzaButtonPressed() {
        // perform segue to the Pizza Creation VC
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        if let pizzaCreationVC = storyboard.instantiateViewController(withIdentifier: "PizzaCreationViewController") as? PizzaCreationViewController {
            pizzaCreationVC.delegate = self // set delegate
            navigationController?.pushViewController(pizzaCreationVC, animated: true)
        }
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return pizzaList.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "PizzaCell", for: indexPath)
        let pizza = pizzaList[indexPath.row]
        cell.textLabel?.numberOfLines = 0 // allows multiple lines
        cell.textLabel?.text = """
            \(pizza.pSize)
                \(pizza.crust)
                \(pizza.cheese)
                \(pizza.meat)
                \(pizza.veggies)
            """
        return cell
    }
    
    func didCreatePizza(_ pizza: Pizza) {
            pizzaList.append(pizza) // add the new pizza to list
            tableView.reloadData() // reload table view
        }


}

