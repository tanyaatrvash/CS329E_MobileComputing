class Weapon {
    let name: String
    let damage: Int
    let allowedClasses: [String]
    
    init(name: String, damage: Int, allowedClasses: [String]) {
        self.name = name
        self.damage = damage
        self.allowedClasses = allowedClasses
    }
}

class Character {
    let name: String
    let maxHealth: Int
    let maxSpellPoints: Int
    var health: Int
    var spellPoints: Int
    var weapon: Weapon?
    var armor: String?
    var armorClass: Int
    
    init(name: String, maxHealth: Int, maxSpellPoints: Int, armorClass: Int) {
        self.name = name
        self.maxHealth = maxHealth
        self.maxSpellPoints = maxSpellPoints
        self.health = maxHealth
        self.spellPoints = maxSpellPoints
        self.armorClass = armorClass
    }
    
    func wield(weapon: Weapon) {
        if weapon.allowedClasses.contains(self.name) {
            self.weapon = weapon
            print("\(self.name) is now wielding a(n) \(weapon.name)")
        } else {
            print("Weapon not allowed for this character class.")
        }
    }
    
    func castSpell(spellName: String, target: Character) {
        var spellCost: Int
        var effectAmount: Int
        
        switch spellName.lowercased() {
        case "fireball":
            spellCost = 3
            effectAmount = 5
            if self.spellPoints >= spellCost {
                print("\(self.name) casts Fireball at \(target.name)")
                target.health -= effectAmount
                self.spellPoints -= spellCost
                print("\(self.name) does \(effectAmount) damage to \(target.name)")
                print("\(target.name) is now down to \(target.health) health.")
            } else {
                print("Insufficient spell points")
            }
        case "lightning bolt":
            spellCost = 10
            effectAmount = 10
            if self.spellPoints >= spellCost {
                print("\(self.name) casts Lightning Bolt at \(target.name)")
                target.health -= effectAmount
                self.spellPoints -= spellCost
                print("\(self.name) does \(effectAmount) damage to \(target.name)")
                print("\(target.name) is now down to \(target.health) health.")
            } else {
                print("Insufficient spell points")
            }
        case "heal":
            spellCost = 5
            effectAmount = 6
            if self.spellPoints >= spellCost {
                print("\(self.name) casts Heal at \(target.name)")
                let healedAmount = min(effectAmount, target.maxHealth - target.health)
                target.health += healedAmount
                self.spellPoints -= spellCost
                print("\(self.name) heals \(target.name) for \(healedAmount) health points")
                print("\(target.name) is now at \(target.health) health.")
            } else {
                print("Insufficient spell points")
            }
        default:
            print("Unknown spell name. Spell failed.")
        }
    }
    
    func displayStats() {
        print("\(name)\n\tCurrent Health: \(health)\n\tCurrent Spell Points: \(spellPoints)\n\tWielding: \(weapon?.name ?? "none")\n\tWearing: \(armor ?? "none")\n\tArmor Class: \(armorClass)")
    }
}


// top level code
let plateMail = Armor(armorType: "plate")
let chainMail = Armor(armorType: "chain")
let sword = Weapon(weaponType: "sword")
let staff = Weapon(weaponType: "staff")
let axe = Weapon(weaponType: "axe")
let gandalf = Wizard(name: "Gandalf the Grey")

gandalf.wield(weaponObject: staff)

let aragorn = Fighter(name: "Aragorn")

aragorn.putOnArmor(armorObject: plateMail)

aragorn.wield(weaponObject: axe)

gandalf.show()

aragorn.show()

gandalf.castSpell(spellName: "Fireball", target: aragorn)

aragorn.fight(opponent: gandalf)

gandalf.show()

aragorn.show()

gandalf.castSpell(spellName: "Lightning Bolt", target: aragorn)

aragorn.wield(weaponObject: sword)

gandalf.show()

aragorn.show()

gandalf.castSpell(spellName: "Heal", target: gandalf)

aragorn.fight(opponent: gandalf)

gandalf.fight(opponent: aragorn)

aragorn.fight(opponent: gandalf)

gandalf.show()

aragorn.show()
