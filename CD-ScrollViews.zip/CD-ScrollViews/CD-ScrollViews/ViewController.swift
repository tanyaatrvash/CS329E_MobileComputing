//
//  ViewController.swift
//  CD-ScrollViews
//
//  Created by Tanya Atrvash on 10/25/24.
//

import UIKit

class ViewController: UIViewController, UIScrollViewDelegate {
    
    var imageView: UIImageView!
    var scrollView: UIScrollView!

    override func viewDidLoad() {
        super.viewDidLoad()
        
        imageView = UIImageView(image: UIImage(named: "Bicyclist_image"))
        
        scrollView = UIScrollView(frame: view.bounds)
        scrollView.backgroundColor = UIColor.black
        scrollView.contentSize = imageView.bounds.size
        
        scrollView.addSubview(imageView)
        view.addSubview(scrollView)
        
        scrollView.delegate = self
        scrollView.minimumZoomScale = 0.1
        scrollView.maximumZoomScale = 4.0
        scrollView.zoomScale = 0.5
        scrollView.contentOffset = CGPoint(x: 1000, y: 450)
    }
    
    func viewForZoomingIn(in scrollView: UIScrollView) -> UIView? {
        return imageView
    }


}

