//
//  CD_SwiftUIBaseballApp.swift
//  CD-SwiftUIBaseball
//
//  Created by Tanya Atrvash on 11/20/24.
//

import SwiftUI

@main
struct CD_SwiftUIBaseballApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
