//
//  TeamRow.swift
//  CD-SwiftUIBaseball
//
//  Created by Tanya Atrvash on 11/20/24.
//

import SwiftUI

struct TeamRow: View {
    var body: some View {
        VStack(alignment: .leading) {
            Text("name")
                .font(.title)
            HStack {
                Text("city")
                    .font(.subheadline)
                Spacer()
                Text("league")
                    .font(.subheadline)
            }
        }
    }
}

#Preview {
    TeamRow()
}
