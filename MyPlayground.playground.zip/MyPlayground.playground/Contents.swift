//// must declare variable using var in front
//var message = "Hello, world"
//print(message)
//
//var a = 4
//var b = 2
//var n = a + b
//
//print(n)
//
//var fact = 1
//
//// factorial function
//// ..< is up to and not including
//// for i in range 1 up to but not including n+1
//// ... = in range x up to y
//// ..< = in range x up to but not including y
//for i in 1 ..< n+1 {
//    fact = fact * i
//    print(i, fact)
//}

//var firstName:String

/*
 Basic Data Types: int, float, double, string, bool
 
 Integer Data Types: Int, Int8, Int16, Int32, Int64 (number of bits)
                    UInt, UInt8, UInt16... (all positive numbers)
 
 Floats --> 32 bits
 Double --> 64 bits
 
 Bool --> true, false
 */

//var number:Int8 = 5 // this means i have 8 bits to play with (256 combinations)
//print(number) // you cannot store a number outside of (-128, 127) because the bits have to account for both pos and neg numbers in 256
//
//var myName = "Tanya"
//print(myName)
//
//let myLastName = "Atrvash" //"let" means im declaring a constant (immutable variable), NOT a (mutable) variable
//// myLastName = "Swift"
//print(myLastName)

//class Person{
//    // instance variables
//    var firstName:String
//    var lastName:String
//    
//    init(first:String, last:String){
//        self.firstName = first
//        self.lastName = last
//    }
//}
//
//var singer = Person(first: "Michael", last: "Jackson")
//print(singer.firstName, singer.lastName)
//
//singer.firstName = "Janet"
//singer.lastName = "Bulko"
//print(singer.firstName, singer.lastName)
//
//singer = Person(first: "Ed", last: "Sheeran")
//print(singer.firstName, singer.lastName)
//// print(singer.lastName + ",", singer.firstName)
//
//// STRING INTERPOLATION
//var outputString = "\(singer.lastName), \(singer.firstName)"
//
//print(outputString)

//var teams = [1,2,3,4,5]
//print(teams)
//
//var team1 = teams[1]
//print(team1)
//
//teams[2] = 22
//print(teams)

//Tuples = a type with two or more elements enclosed in parentheses

//var myTuple:(String, Double, Bool) = ("hello", 3.14, true)
//print(myTuple)
//
//let myOtherTuple: (String, (Double, Bool)) = ("hello", (3.14,true))
//
//print(myOtherTuple.1.0)

/* Flow Control
 
 Operators
    Logical: && || ! (we do NOT use "and", "or", and "not"
    Relational: > < >= <= != ==
    
 if statement: no surprises
    Python: elif
    Swift:  else if
 
 for statement:
 
 */

//for index in 1 ... 5 {
//    print("The count is \(index)")
//}
//
//let names = ["Harry", "Zayn", "Louis", "Niall", "Liam"]
//
//for name in names{
//    print("Hello, \(name)!")
//}
//
////while statement "pre-test" format
//// check first, possible we never check the loop at all
//
//var i = 0
//
//while i < 5 {
//    print("Count is \(i)")
//    i += 1
//}
//
//// "post-test" format
//// run the loop, then check to see if we can run it again at the end
//
//var j = 0
//
//repeat{
//    print("Count is \(j)")
//    j += 1
//} while j < 5


//functions
func printNames(firstName first:String,lastName last:String) {
    print("\(last), \(first)")
}

printNames(firstName: "Hermione", lastName: "Granger")

func printNames2(_ first:String,_ last:String) {
    print("\(last), \(first)")
}

printNames2("Ron", "Weasley")

// default parameter value
func printNamesAgain(firstName first:String, lastName last:String = "Granger") {
    print("\(last), \(first)")
}
printNamesAgain(firstName: "Harry")

// ---------------------------------------------------------------------------
func returnGreeting(personName:String) -> String {
    let newGreeting = "Hello, " + personName + "!"
    return newGreeting
}

print(returnGreeting(personName: "Ron"))

// ---------------------------------------------------------------------------
func findMin(myArray:[Int]) -> Int {
    
    var currentMin = myArray[0]
    
    for value in myArray[1 ..< myArray.count] {
        
        if value < currentMin {
            currentMin = value
        }
    }
    
    return currentMin
}

let minVal = findMin(myArray: [3, 65, 4, 9, 2, 7])
print(minVal)

func findMaxAndMin(myArray:[Int]) -> (smallest:Int, largest:Int) {
    
    var currentMin = myArray[0]
    var currentMax = myArray[0]
    
    for value in myArray[1 ..< myArray.count] {
        if value > currentMax {
            currentMax = value
        } else if value < currentMin {
            currentMin = value
        }
    }
    
    return (currentMin, currentMax)
}

let result = findMaxAndMin(myArray: [3, 65, 4, 9, 2, 7])
print(result.smallest)
print(result.largest)
