// Project: AtrvashTanya-HW7
// EID: tka435
// Course: CS329E

//  CountdownViewController.swift
//  AtrvashTanya-HW7.5
//
//  Created by Tanya Atrvash on 11/5/24.
//

import UIKit

class CountdownViewController: UIViewController {
    
    var delegate: UIViewController!
    var event:String!
    var location:String!
    var remainingTime:Int!
    var timer: Timer?
    
    var queue: DispatchQueue!
    var isTimerRunning = true
    
    @IBOutlet weak var eventCount: UILabel!
    @IBOutlet weak var locationCount: UILabel!
    @IBOutlet weak var timeCount: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        if let event = event, let location = location, let remainingTime = remainingTime {
            eventCount.text = event
            locationCount.text = location
            timeCount.text = "\(remainingTime)"
        }
        
        queue = DispatchQueue(label: "countdown.queue", qos: .utility)
        queue.async {
            self.startCountdown()
        }
    }
    
    func startCountdown() {
        while isTimerRunning, let time = remainingTime, time > 0 {
            sleep(1)  // wait timer for 1 second
            
            DispatchQueue.main.async {
                if let time = self.remainingTime, time > 0 {
                    self.remainingTime! -= 1
                    self.timeCount.text = "\(self.remainingTime!)"
                } else {
                    self.isTimerRunning = false
                }
            }
        }
        
    }
        
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        
        isTimerRunning = false
        if let delegate = delegate as? CountdownTimer {
            delegate.countdown(newTime: remainingTime)
        }
    }
        
}
