// Project: AtrvashTanya-HW7
// EID: tka435
// Course: CS329E

//  protocols.swift
//  AtrvashTanya-HW7.5
//
//  Created by Tanya Atrvash on 11/5/24.
//

import Foundation

protocol AddTimerToTable {
    func addTimer(newTimer: Timer)
}

protocol CountdownTimer {
    func countdown(newTime: Int)
}
