// Project: AtrvashTanya-HW7
// EID: tka435
// Course: CS329E

//  ViewController.swift
//  AtrvashTanya-HW7.5
//
//  Created by Tanya Atrvash on 11/5/24.
//

import UIKit

var timers: [Timer] = []

class ViewController: UIViewController, UITableViewDelegate, UITableViewDataSource, AddTimerToTable, CountdownTimer {
    
    @IBOutlet weak var tableView: UITableView!
    
    let textCellIdentifier = "TimerTable-ViewCell"
    let segueIdentifier = "timerCellSegue"
    let addTimerSegueIdentifier = "timerCellSegue"
    let countdownSegueIdentifier = "countdownSegue"
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        tableView.delegate = self
        tableView.dataSource = self
        navigationItem.title = "Timer"
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return timers.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(
            withIdentifier: textCellIdentifier,
            for: indexPath
        ) as! TimerTable_ViewCell
        
        let timer = timers[indexPath.row]
        cell.eventLabel.text = "Event \(timer.event)"
        cell.locationLabel.text = "Location \(timer.location)"
        cell.timeLabel.text = "Remaining Time(s) \(timer.remainingTime)s"
        
        return cell
    }
    
    @objc func addTimerTapped() {
        performSegue(withIdentifier: addTimerSegueIdentifier, sender: self)
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == addTimerSegueIdentifier {
            let destination = segue.destination as! AddTimerViewController
            destination.delegate = self
        }
        else if segue.identifier == countdownSegueIdentifier,
                let destination = segue.destination as? CountdownViewController,
                let selectedIndex = tableView.indexPathForSelectedRow?.row {
            let selectedTimer = timers[selectedIndex]
            destination.event = selectedTimer.event
            destination.location = selectedTimer.location
            destination.remainingTime = selectedTimer.remainingTime
            destination.delegate = self
        }
    }
    
    func addTimer(newTimer: Timer) {
        timers.append(newTimer)
        tableView.reloadData()
    }
    
    func countdown(newTime: Int) {
        if let index = tableView.indexPathForSelectedRow?.row {
            timers[index].remainingTime = newTime
            tableView.reloadRows(at: [IndexPath(row: index, section: 0)], with: .none)
        }
    }

}

