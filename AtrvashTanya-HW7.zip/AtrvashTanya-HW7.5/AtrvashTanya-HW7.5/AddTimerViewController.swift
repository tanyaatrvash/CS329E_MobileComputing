// Project: AtrvashTanya-HW7
// EID: tka435
// Course: CS329E

//  AddTimerViewController.swift
//  AtrvashTanya-HW7.5
//
//  Created by Tanya Atrvash on 11/5/24.
//

import UIKit

class AddTimerViewController: UIViewController {
    
    @IBOutlet weak var eventTextField: UITextField!
    @IBOutlet weak var locationTextField: UITextField!
    @IBOutlet weak var timeTextField: UITextField!
    
    var delegate: UIViewController!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Do any additional setup after loading the view.
    }
    
    @IBAction func saveButtonPressed(_ sender: Any) {
        guard let event = eventTextField.text, !event.isEmpty,
              let location = locationTextField.text, !location.isEmpty,
              let timeText = timeTextField.text, !timeText.isEmpty,
              let time = Int(timeText) else {
            return
        }
        
        let newTimer = Timer(event: event, location: location, remainingTime: time)
        if let delegate = delegate as? AddTimerToTable {
            print("Adding new timer: \(newTimer.event), \(newTimer.location), \(newTimer.remainingTime)")
                // debugging purposes
            delegate.addTimer(newTimer: newTimer)
        } else {
            print("delete didn't work") // debugging purposes
        }
        
    }
}
