// Project: AtrvashTanya-HW7
// EID: tka435
// Course: CS329E

//  Timer.swift
//  AtrvashTanya-HW7.5
//
//  Created by Tanya Atrvash on 11/5/24.
//

import Foundation

class Timer {
    var event:String
    var location:String
    var remainingTime:Int
    
    init(event: String, location: String, remainingTime: Int) {
        self.event = event
        self.location = location
        self.remainingTime = remainingTime
    }
}
