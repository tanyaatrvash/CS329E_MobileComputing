// Project: AtrvashTanya-HW7
// EID: tka435
// Course: CS329E

//  TimerTable-ViewCell.swift
//  AtrvashTanya-HW7.5
//
//  Created by Tanya Atrvash on 11/5/24.
//

import UIKit

class TimerTable_ViewCell: UITableViewCell {

    @IBOutlet weak var eventLabel: UILabel!
    @IBOutlet weak var timeLabel: UILabel!
    @IBOutlet weak var locationLabel: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
