//
//  ViewController.swift
//  CD-CoreData
//
//  Created by Tanya Atrvash on 10/22/24.
//

import UIKit
import CoreData

let appDelegate = UIApplication.shared.delegate as! AppDelegate
let context = appDelegate.persistentContainer.viewContext

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        
        demoCoreData()
    }
    
    func demoCoreData() {
        
        clearCoreData()
        
        print("\n\nStarting Core Data Demo")
        
        storePerson(name: "Justin Timberlake", age:43)
        storePerson(name: "Alicia Keys", age:43)
        storePerson(name: "Billie Eilish", age:22)
        storePerson(name: "Carrie Underwood", age:41)
        print("Stored four people")
        
        let fetchedResults = retrievePeople()
        
        for person in fetchedResults {
            if let personName = person.value(forKey: "name") {
                if let personAge = person.value(forKey: "age") {
                    print("Retrieved: \(personName), age: \(personAge)")
                }
            }
        }
        
    }
    
    func storePerson(name:String, age:Int32) {
        let person = NSEntityDescription.insertNewObject(forEntityName: "Person", into: context)
        
        person.setValue(name, forKey: "name")
        person.setValue(age, forKey: "age")
        
        saveContext()
        
    }
    
    func retrievePeople() -> [NSManagedObject] {
        let request = NSFetchRequest<NSFetchRequestResult>(entityName: "Person")
        var fetchedResults: [NSManagedObject]?
        
//        let predicate = NSPredicate(format: "age = 41") // true or false if something = 41
        let predicate = NSPredicate(format: "name CONTAINS[c] 'ie'")
        request.predicate = predicate
        
        do {
            try fetchedResults = context.fetch(request) as? [NSManagedObject]
        }catch{
            print("Error occurred while retrieving data")
            abort()
        }
        
        return fetchedResults!
        
    }
    
    func clearCoreData() {
        let request = NSFetchRequest<NSFetchRequestResult>(entityName: "Person")
        var fetchedResults: [NSManagedObject]
        
        do {
            try fetchedResults = context.fetch(request) as! [NSManagedObject]
            if fetchedResults.count > 0 {
                for result in fetchedResults {
                    context.delete(result)
                    print("\(result.value(forKey: "name")!) has been deleted")
                }
            }
            
            saveContext()
            
        }catch{
            print("Error occurred while retrieving data")
            abort()
        }
        
    }
    
    func saveContext () {
        if context.hasChanges {
            do {
                try context.save()
            } catch {
                let nserror = error as NSError
                fatalError("Unresolved error \(nserror), \(nserror.userInfo)")
            }
        }
    }


}

