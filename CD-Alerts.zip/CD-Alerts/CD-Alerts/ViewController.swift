//
//  ViewController.swift
//  CD-Alerts
//
//  Created by Tanya Atrvash on 10/13/24.
//

import UIKit

let choices = [
    "Simple UIAlertViewController",
    "UIAlertViewController with Multiple Buttons",
    "Standard UI Action Sheet",
    "UIAlertViewController with Text Field"
]

class ViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {
    @IBOutlet weak var tableView: UITableView!
    
    let textCellIdentifier = "TextCell"
    override func viewDidLoad() {
        super.viewDidLoad()
        tableView.delegate = self
        tableView.dataSource = self
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return choices.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: textCellIdentifier, for: indexPath)
        let row = indexPath.row
        cell.textLabel?.text = choices[row]
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        tableView.deselectRow(at: indexPath, animated: true)
        let rowValue = choices[indexPath.row]
        
        switch indexPath.row {
        case 0:         // simple
            let controller = UIAlertController(
                title: "Alert Controller",
                message: rowValue,
                preferredStyle: .alert
            )
            
            controller.addAction(UIAlertAction(title: "Cancel", style: .cancel))
            controller.addAction(UIAlertAction(title: "OK", style: .default))
            present(controller, animated: true)
            
        case 1:         // multiple buttons
            let controller = UIAlertController(
                title: "Alert Controller",
                message: rowValue,
                preferredStyle: .alert
            )
            
            controller.addAction(UIAlertAction(title: "One", style: .default, handler: alertHandler(alert:)))
            controller.addAction(UIAlertAction(title: "Two", style: .default, handler: {
                (alert) in print("You pressed button Two")
            }
            ))
            controller.addAction(UIAlertAction(title: "Three", style: .default) {
                (alert) in print("You pressed button Three")
            }
            
            )
            controller.addAction(UIAlertAction(title: "Four", style: .default))
            controller.addAction(UIAlertAction(title: "Cancel", style: .cancel))
            
            present(controller, animated: true)
            
        case 2:         // standard action sheet
            let controller = UIAlertController(
                title: "Action Sheet",
                message: rowValue,
                preferredStyle: .actionSheet
            )
            
            controller.addAction(UIAlertAction(
                title: "Cancel",
                style: .cancel) {
                    (action) in print("Cancel action")
                }
            )
            
            controller.addAction(UIAlertAction(
                title: "OK",
                style: .default) {
                    (action) in print("Accept data")
                }
            )
            
            controller.addAction(UIAlertAction(
                title: "Delete",
                style: .destructive) {
                    (action) in print("Destroy data")
                }
            )
            
            present(controller, animated: true)
            
        case 3:         // with text field
            let controller = UIAlertController(
                title: "Action Sheet",
                message: rowValue,
                preferredStyle: .actionSheet
            )
            
            controller.addAction(UIAlertAction(
                title: "Cancel",
                style: .cancel)
            )
            
            // dynamically create a UITextField
            // takes as a parameter a FUNCTION that creates a UITextField object
                // and adds it to an array called "TextFields"
            
            controller.addTextField() {
                (textField) in textField.placeholder = "Enter something"
            }
            
            controller.addAction(UIAlertAction(
                title: "OK",
                style: .default) {
                    (action) in let enteredText = controller.textFields![0].text
                    print(enteredText!)
                }
            )
            
            present(controller, animated: true)
            
        default:
            let controller = UIAlertController(
                title: "Unidentified Alert Type",
                message: rowValue,
                preferredStyle: .alert
            )
            
            controller.addAction(UIAlertAction(
                title: "This should not happen",
                style: .default
            ))
            
            present(controller, animated: true)
        }
    }
    
    
    func alertHandler(alert:UIAlertAction!) {
        print("You pressed button One")
    }
    

}

