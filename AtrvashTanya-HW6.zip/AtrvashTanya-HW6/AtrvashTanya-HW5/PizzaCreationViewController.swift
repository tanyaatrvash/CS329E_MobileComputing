// Project: AtrvashTanya-HW6
// EID: tka435
// Course: CS329E

//  PizzaCreationViewController.swift
//  AtrvashTanya-HW5
//
//  Created by Tanya Atrvash on 10/15/24.
//

import UIKit
import CoreData

let appDelegate = UIApplication.shared.delegate as! AppDelegate

protocol PizzaCreationDelegate: AnyObject {
    func didCreatePizza(_ pizza: Pizza)
}

class Pizza {
    var pSize: String
    var crust: String
    var cheese: String
    var meat: String
    var veggies: String
    
    init(pSize: String, crust: String, cheese: String, meat: String, veggies: String) {
        self.pSize = pSize
        self.crust = crust
        self.cheese = cheese
        self.meat = meat
        self.veggies = veggies
    }
    
    // Convert NSManagedObject to Pizza
    static func fromManagedObject(_ managedObject: NSManagedObject) -> Pizza {
        return Pizza(
            pSize: managedObject.value(forKey: "size") as? String ?? "",
            crust: managedObject.value(forKey: "crust") as? String ?? "",
            cheese: managedObject.value(forKey: "cheese") as? String ?? "",
            meat: managedObject.value(forKey: "meat") as? String ?? "",
            veggies: managedObject.value(forKey: "veggies") as? String ?? ""
        )
    }
}

class PizzaCreationViewController: UIViewController {
    
    weak var delegate: PizzaCreationDelegate?

    @IBOutlet weak var pizzaSizeSegmentedControl: UISegmentedControl!
    @IBOutlet weak var summaryLabel: UILabel!
    
    var sizeSelection: String = "Small"
    var crustSelection: String?
    var cheeseSelection: String?
    var meatSelection: String?
    var veggiesSelection: String?
    
    override func viewDidLoad() {
        super.viewDidLoad()
    }
    
    
    // function to update pizza size
    @IBAction func sizeChanged(_ sender: Any) {
        sizeSelection = (sender as AnyObject).titleForSegment(at: (sender as AnyObject).selectedSegmentIndex) ?? "Small"

    }
    
    // function to set crust alert
    @IBAction func selectCrustPressed(_ sender: Any) {
        let alert = UIAlertController(title: "Select crust", message: "Choose a crust type:", preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "Thin crust", style: .default, handler: { _ in
            self.crustSelection = "Thin crust"
        }))
        alert.addAction(UIAlertAction(title: "Thick crust", style: .default, handler: { _ in
            self.crustSelection = "Thick crust"
        }))
            
        present(alert, animated: true)
    }
    
    
    // function to set cheese action sheet
    @IBAction func selectCheesePressed(_ sender: Any) {
        let actionSheet = UIAlertController(title: "Select cheese", message: "Choose a cheese type:", preferredStyle: .actionSheet)
        actionSheet.addAction(UIAlertAction(title: "Regular cheese", style: .default, handler: { _ in
            self.cheeseSelection = "Regular cheese"
        }))
        actionSheet.addAction(UIAlertAction(title: "No cheese", style: .default, handler: { _ in
            self.cheeseSelection = "No cheese"
        }))
        actionSheet.addAction(UIAlertAction(title: "Double cheese", style: .default, handler: { _ in
            self.cheeseSelection = "Double cheese"
        }))

        present(actionSheet, animated: true)
    }
    
    
    // function to set meat action shet
    @IBAction func selectMeatPressed(_ sender: Any) {
        let actionSheet = UIAlertController(title: "Select meat", message: "Choose one meat:", preferredStyle: .actionSheet)
        actionSheet.addAction(UIAlertAction(title: "Pepperoni", style: .default, handler: { _ in
            self.meatSelection = "Pepperoni"
        }))
        actionSheet.addAction(UIAlertAction(title: "Sausage", style: .default, handler: { _ in
            self.meatSelection = "Sausage"
        }))
        actionSheet.addAction(UIAlertAction(title: "Canadian Bacon", style: .default, handler: { _ in
            self.meatSelection = "Canadian Bacon"
        }))

        present(actionSheet, animated: true)
    }
    
    
    // function to set veggie action sheet
    @IBAction func selectVeggiesPressed(_ sender: Any) {
        let actionSheet = UIAlertController(title: "Select veggies", message: "Choose your veggies:", preferredStyle: .actionSheet)
        actionSheet.addAction(UIAlertAction(title: "Mushroom", style: .default, handler: { _ in
            self.veggiesSelection = "Mushroom"
        }))
        actionSheet.addAction(UIAlertAction(title: "Onion", style: .default, handler: { _ in
            self.veggiesSelection = "Onion"
        }))
        actionSheet.addAction(UIAlertAction(title: "Green Olive", style: .default, handler: { _ in
            self.veggiesSelection = "Green Olive"
        }))
        actionSheet.addAction(UIAlertAction(title: "Black Olive", style: .default, handler: { _ in
            self.veggiesSelection = "Black Olive"
        }))
        actionSheet.addAction(UIAlertAction(title: "None", style: .default, handler: { _ in
            self.veggiesSelection = "None"
        }))

        present(actionSheet, animated: true)
    }
    
    
    // function for done button
    @IBAction func doneButtonPressed(_ sender: Any) {
        var errorMessage: String?
        
        // check for selections and set error message for a specific error
        if crustSelection == nil {
            errorMessage = "Please select a crust type."
        } else if cheeseSelection == nil {
            errorMessage = "Please select a cheese option."
        } else if meatSelection == nil {
            errorMessage = "Please select a meat option."
        } else if veggiesSelection == nil {
            errorMessage = "Please select a veggie option."
        }

        // show error message if any selection is missing
        if let message = errorMessage {
            let alert = UIAlertController(title: "Missing Ingredient", message: message, preferredStyle: .alert)
            alert.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
            self.present(alert, animated: true, completion: nil)
            return
        }
        
//        // debug prints to check selections
//            print("Size: \(sizeSelection)")
//            print("Crust: \(String(describing: crustSelection))")
//            print("Cheese: \(String(describing: cheeseSelection))")
//            print("Meat: \(String(describing: meatSelection))")
//            print("Veggies: \(String(describing: veggiesSelection))")

        // update summaryLabel
        summaryLabel.text = "One \(sizeSelection) pizza with:\n" +
                                "   \(crustSelection!)\n" +
                                "   \(cheeseSelection!)\n" +
                                "   \(meatSelection!)\n" +
                                "   \(veggiesSelection!)"
        
        let newPizza = Pizza(pSize: sizeSelection,
                                  crust: crustSelection ?? "No crust selected",
                                  cheese: cheeseSelection ?? "No cheese selected",
                                  meat: meatSelection ?? "No meat selected",
                                  veggies: veggiesSelection ?? "No veggies selected")

        // notify delegate
        delegate?.didCreatePizza(newPizza)
        

    }
    
}
