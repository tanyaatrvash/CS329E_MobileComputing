// Project: AtrvashTanya-HW6
// EID: tka435
// Course: CS329E

//  LoginViewController.swift
//  AtrvashTanya-HW5
//
//  Created by Tanya Atrvash on 10/26/24.
//

import UIKit
import FirebaseAuth

class LoginViewController: UIViewController {

    @IBOutlet weak var segmentedControl: UISegmentedControl!
    @IBOutlet weak var userIdTextField: UITextField!
    @IBOutlet weak var passwordTextField: UITextField!
    @IBOutlet weak var confirmPasswordTextField: UITextField!
    @IBOutlet weak var confirmPasswordLabel: UILabel!
    @IBOutlet weak var signInButton: UIButton!
    @IBOutlet weak var statusLabel: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        setupUI()
    }
    
    private func setupUI() {
        // initially hide confirm password elements for login mode
        confirmPasswordTextField.isHidden = true
        confirmPasswordLabel.isHidden = true
        
        // clear status label
        statusLabel.text = ""
        
        // title based on initial mode
        signInButton.setTitle("Sign In", for: .normal)
        
        passwordTextField.isSecureTextEntry = true
        confirmPasswordTextField.isSecureTextEntry = true
    }
    
    
    @IBAction func segmentChanged(_ sender: UISegmentedControl) {
        // toggle selected segment
        let isSignUp = sender.selectedSegmentIndex == 1
        
        // show/hide confirm password elements
        confirmPasswordTextField.isHidden = !isSignUp
        confirmPasswordLabel.isHidden = !isSignUp
        
        // update button title
        signInButton.setTitle(isSignUp ? "Sign Up" : "Sign In", for: .normal)
        
        // clear status label & text fields
        statusLabel.text = ""
        if isSignUp {
            confirmPasswordTextField.text = ""
        }
    }
    
    @IBAction func signInButtonPressed(_ sender: UIButton) {
        // clear status label
        statusLabel.text = ""
        
        guard let email = userIdTextField.text, !email.isEmpty,
              let password = passwordTextField.text, !password.isEmpty else {
            statusLabel.text = "Please fill in all fields"
            return
        }
        
        if segmentedControl.selectedSegmentIndex == 1 {
            // sign up
            guard let confirmPassword = confirmPasswordTextField.text, !confirmPassword.isEmpty else {
                statusLabel.text = "Please confirm your password"
                return
            }
            
            guard password == confirmPassword else {
                statusLabel.text = "Passwords do not match"
                return
            }
            
            // create user in Firebase
            Auth.auth().createUser(withEmail: email, password: password) { [weak self] result, error in
                if let error = error {
                    self?.statusLabel.text = error.localizedDescription
                    return
                }
                
                // successfully created user
                self?.performSegue(withIdentifier: "loginSegue", sender: nil)
            }
        } else {
            // sign in
            Auth.auth().signIn(withEmail: email, password: password) { [weak self] result, error in
                if let error = error {
                    self?.statusLabel.text = error.localizedDescription
                    return
                }
                
                // successfully signed in
                self?.performSegue(withIdentifier: "loginSegue", sender: nil)
            }
        }
    }
    
}
