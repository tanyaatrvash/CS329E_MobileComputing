// Project: AtrvashTanya-HW6
// EID: tka435
// Course: CS329E

//  ViewController.swift
//  AtrvashTanya-HW5
//
//  Created by Tanya Atrvash on 10/14/24.
//

import UIKit
import CoreData
import FirebaseAuth

let context = (UIApplication.shared.delegate as! AppDelegate).persistentContainer.viewContext

// pizza list to store created pizzas
var pizzaList: [Pizza] = []

class ViewController: UIViewController,UITableViewDelegate, UITableViewDataSource, PizzaCreationDelegate {
    
    @IBOutlet weak var tableView: UITableView!
        
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // nav bar & + button
        navigationItem.rightBarButtonItem = UIBarButtonItem(barButtonSystemItem: .add, target: self, action: #selector(addPizzaButtonPressed))
        
        // setting back button to "Pizza Order"
        let backButton = UIBarButtonItem()
        backButton.title = "Pizza Order"
        navigationItem.backBarButtonItem = backButton
        
        // set up table view
        tableView.delegate = self
        tableView.dataSource = self
        
        // sign out button
        let signOutButton = UIBarButtonItem(title: "Sign Out",
                                          style: .plain,
                                          target: self,
                                          action: #selector(signOutPressed))
        navigationItem.leftBarButtonItem = signOutButton
        
        // check if user is signed in
        if Auth.auth().currentUser == nil {
            // no user is signed in --> go to login screen
            performSegue(withIdentifier: "MainToLogin", sender: nil)
        }
        
        // fetch pizza data
        fetchPizzaData()
}
    
    func fetchPizzaData() {
        let fetchRequest: NSFetchRequest<PizzaEntity> = PizzaEntity.fetchRequest()
        
        do {
            let fetchedPizzaEntities = try context.fetch(fetchRequest)
            // convert PizzaEntity objects to Pizza objects
            pizzaList = fetchedPizzaEntities.map { entity in
                return Pizza(
                    pSize: entity.pSize ?? "",
                    crust: entity.crust ?? "",
                    cheese: entity.cheese ?? "",
                    meat: entity.meat ?? "",
                    veggies: entity.veggies ?? ""
                )
            }
            tableView.reloadData()
        } catch {
            print("Error fetching data from Core Data: \(error)")
        }
    }
    
    
    // action for + button
    @objc func addPizzaButtonPressed() {
        // perform segue to the Pizza Creation VC
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        if let pizzaCreationVC = storyboard.instantiateViewController(withIdentifier: "PizzaCreationViewController") as? PizzaCreationViewController {
            pizzaCreationVC.delegate = self // set delegate
            navigationController?.pushViewController(pizzaCreationVC, animated: true)
        }
    }
    
    @objc private func signOutPressed() {
        do {
            try Auth.auth().signOut()
            // go to login screen
            performSegue(withIdentifier: "MainToLogin", sender: nil)
        } catch {
            print("Error signing out: \(error.localizedDescription)")
        }
    }
    
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        
        // check if user is signed in whenever view appears
        if Auth.auth().currentUser == nil {
            performSegue(withIdentifier: "MainToLogin", sender: nil)
        }
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return pizzaList.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "PizzaCell", for: indexPath)
        let pizza = pizzaList[indexPath.row]
        cell.textLabel?.numberOfLines = 0 // allows multiple lines
        cell.textLabel?.text = """
            \(pizza.pSize)
                \(pizza.crust)
                \(pizza.cheese)
                \(pizza.meat)
                \(pizza.veggies)
            """
        return cell
    }
    
    func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCell.EditingStyle, forRowAt indexPath: IndexPath) {
        if editingStyle == .delete {
            // delete from Core Data
            let pizzaToDelete = pizzaList[indexPath.row]
            deletePizzaFromCoreData(pizzaToDelete)
            
            // remove from array & delete row in table view
            pizzaList.remove(at: indexPath.row)
            tableView.deleteRows(at: [indexPath], with: .fade)
        }
    }

    func deletePizzaFromCoreData(_ pizza: Pizza) {
        let fetchRequest: NSFetchRequest<PizzaEntity> = PizzaEntity.fetchRequest()
        fetchRequest.predicate = NSPredicate(format: "pSize == %@ AND crust == %@ AND cheese == %@ AND meat == %@ AND veggies == %@", pizza.pSize, pizza.crust, pizza.cheese, pizza.meat, pizza.veggies)
        
        do {
            let results = try context.fetch(fetchRequest)
            for object in results {
                context.delete(object)
            }
            
            try context.save()
            
        } catch {
            print("Error deleting pizza from Core Data: \(error)")
        }
    }


    
    func didCreatePizza(_ pizza: Pizza) {
            pizzaList.append(pizza) // add the new pizza to list
            tableView.reloadData() // reload table view
        }


}

