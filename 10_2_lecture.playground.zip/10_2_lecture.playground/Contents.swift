func myCompare(x: [Int], y: [Int]) -> Bool {
    return x[0] < y[0]
}

var myArray = [ [1,2,3], [2,4,8], [9,1,7], [4,3,9], [6,1,4] ]
print(myArray.sorted(by: myCompare))


