//
//  TeamViewController.swift
//  CD-TableView
//
//  Created by Tanya Atrvash on 9/23/24.
//

import UIKit

class TeamViewController: UIViewController {
    
    @IBOutlet weak var cityLabel: UILabel!
    @IBOutlet weak var teamLabel: UILabel!
    
    var teamName = ""
    
    override func viewDidLoad() {
        super.viewDidLoad()

        teamLabel.text = "Team selected: \(teamName)"
        
        // does linear search to find the first index of the team name in question
        let teamIndex = teams.firstIndex(of: teamName)
        cityLabel.text = "City selected: \(cities[teamIndex!])"
    }


}
