var value:Int? = 6

if value != nil {
    let tenTimes = 10 * value!
    print(tenTimes)
} else {
    print("Dont do that")
}

// optional binding suing if-let
if let name = optName {
    
}
