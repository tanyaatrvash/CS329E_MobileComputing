//
//  ViewController.swift
//  CD-Camera
//
//  Created by Tanya Atrvash on 11/11/24.
//

import UIKit
import AVFoundation

class ViewController: UIViewController, UIImagePickerControllerDelegate, UINavigationControllerDelegate {

    @IBOutlet weak var imageView: UIImageView!
    
    let picker = UIImagePickerController()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        picker.delegate = self
    }

    @IBAction func libraryButtonSelected(_ sender: Any) {
        picker.allowsEditing = false
        picker.sourceType = .photoLibrary
        present(picker, animated: true)
    }
    
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey : Any]) {
        // infoKey is a dictionary containing original image, edited image (if editing is allowed), filesystem URL,
        // any relevant editing info, metadata (GPS location, etc)
        
        let chosenImage = info[.originalImage] as! UIImage
        
        // shrink it to visible size
        imageView.contentMode = .scaleAspectFit
        
        // put picture into imageView
        imageView.image = chosenImage
        
        dismiss(animated: true)
    }
    
    func imagePickerControllerDidCancel(_ picker: UIImagePickerController) {
        print("User cancelled out")
        dismiss(animated: true)
    }
    
    @IBAction func cameraButtonSelected(_ sender: Any) {
        if UIImagePickerController.availableCaptureModes(for: .rear) != nil {
            switch AVCaptureDevice.authorizationStatus(for: .video) {
            case .notDetermined:
                AVCaptureDevice.requestAccess(for: .video) {
                    (accessGranted) in
                    guard accessGranted == true else {return}
                }
            case .authorized:
                break
            default:
                break 
            }
            
            // come here if i have access to the rear camera
            picker.sourceType = .camera
            picker.allowsEditing = false
            picker.cameraCaptureMode = .photo
            present(picker, animated: true)
            
        }else {
            // there is no rear camera
            let alertVC = UIAlertController(
                title: "No camera",
                message: "Sorry, this device doesn't have a camera",
                preferredStyle: .alert
            )
            let okAction = UIAlertAction(title: "OK", style: .default)
            alertVC.addAction(okAction)
            present(alertVC, animated:true)
        }
        
    }
    
}

