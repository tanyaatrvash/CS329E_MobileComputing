// AtrvashTanya-HW9
// EID: tka435
// Course: CS329E

//  ViewController.swift
//  AtrvashTanya-HW9
//
//  Created by Tanya Atrvash on 11/21/24.
//

import UIKit

class ViewController: UIViewController {
    
    private var blockView: UIView!
    private var timer: Timer?
    private var currentDirection: Direction = .down
    private var isGameOver = false
    
    private enum Direction {
        case up, down, left, right
    }

    override func viewDidLoad() {
        super.viewDidLoad()
        setupBlock()
        setupGestureRecognizers()
    }
    
    private func setupBlock() {
        let blockWidth = view.bounds.width / 9
        let blockHeight = view.bounds.height / 19
        
        blockView = UIView(frame: CGRect(x: 0, y: 0, width: blockWidth, height: blockHeight))
        blockView.backgroundColor = .green
        view.addSubview(blockView)
        
        // position block in center
        centerBlock()
    }
    
    private func setupGestureRecognizers() {
        // tap gesture
        let tapGesture = UITapGestureRecognizer(target: self, action: #selector(handleTap(_:)))
        view.addGestureRecognizer(tapGesture)
        
        // swipe gestures
        let directions: [UISwipeGestureRecognizer.Direction] = [.up, .down, .left, .right]
        for direction in directions {
            let swipeGesture = UISwipeGestureRecognizer(target: self, action: #selector(handleSwipe(_:)))
            swipeGesture.direction = direction
            view.addGestureRecognizer(swipeGesture)
        }
    }
    
    private func centerBlock() {
        let centerX = (view.bounds.width - blockView.bounds.width) / 2
        let centerY = (view.bounds.height - blockView.bounds.height) / 2
        blockView.frame.origin = CGPoint(x: centerX, y: centerY)
    }
    
    
    private func startMoving() {
        timer?.invalidate()
        timer = Timer.scheduledTimer(timeInterval: 0.3, target: self, selector: #selector(moveBlock), userInfo: nil, repeats: true)
    }
    
    private func checkBoundaries() -> Bool {
        let viewFrame = view.bounds
        let blockFrame = blockView.frame
        
        switch currentDirection {
        case .up:
            return blockFrame.minY <= 0
        case .down:
            return blockFrame.maxY >= viewFrame.height
        case .left:
            return blockFrame.minX <= 1
        case .right:
            return blockFrame.maxX >= viewFrame.width
        }
    }
    
    @objc private func moveBlock() {
        if isGameOver { return }
        
        let stepSize = currentDirection == .up || currentDirection == .down ?
            blockView.bounds.height : blockView.bounds.width
            
        var newOrigin = blockView.frame.origin
        
        switch currentDirection {
        case .up:
            newOrigin.y -= stepSize
        case .down:
            newOrigin.y += stepSize
        case .left:
            newOrigin.x -= stepSize
        case .right:
            newOrigin.x += stepSize
        }
        
        blockView.frame.origin = newOrigin
        
        if checkBoundaries() {
            timer?.invalidate()
            blockView.backgroundColor = .red
            isGameOver = true
        }
    }
    
    @objc private func handleTap(_ gesture: UITapGestureRecognizer) {
        isGameOver = false
        blockView.backgroundColor = .green
        centerBlock()
        currentDirection = .down
        startMoving()
    }
    
    @objc private func handleSwipe(_ gesture: UISwipeGestureRecognizer) {
        if isGameOver { return }
        
        switch gesture.direction {
        case .up:
            currentDirection = .up
        case .down:
            currentDirection = .down
        case .left:
            currentDirection = .left
        case .right:
            currentDirection = .right
        default:
            break
        }
    }


}

