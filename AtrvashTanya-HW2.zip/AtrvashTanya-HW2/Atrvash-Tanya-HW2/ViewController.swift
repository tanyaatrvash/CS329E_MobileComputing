// Project: AtrvashTanya-HW2
// EID: tka435
// Course: CS329E

//  ViewController.swift
//  Atrvash-Tanya-HW2
//
//  Created by Tanya Atrvash on 9/17/24.
//

import UIKit

class ViewController: UIViewController, UITextFieldDelegate {

    @IBOutlet weak var userID: UITextField!
    @IBOutlet weak var Password: UITextField!
    @IBOutlet weak var statusLabel: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        userID.delegate = self
        Password.delegate = self
    }

    @IBAction func buttonPressed(_ sender: Any) {
        // Check if either userID or Password is empty
            if userID.text!.isEmpty || Password.text!.isEmpty {
                // Update status label with "Invalid login" if any field is empty
                statusLabel.text = "Invalid login"
            } else {
                // Update status label with "<userID> logged in" if both fields are filled
                let name = userID.text!
                statusLabel.text = "\(name) logged in"
            }
        
    }
    
    // Called when 'return' key pressed

     func textFieldShouldReturn(_ textField:UITextField) -> Bool {
         textField.resignFirstResponder()
         return true
     }
     
     // Called when the user clicks on the view outside of the UITextField

     override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
         self.view.endEditing(true)
     }
    
}

