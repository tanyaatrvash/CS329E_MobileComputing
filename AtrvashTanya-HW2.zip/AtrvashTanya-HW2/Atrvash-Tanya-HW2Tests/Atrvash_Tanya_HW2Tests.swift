//
//  Atrvash_Tanya_HW2Tests.swift
//  Atrvash-Tanya-HW2Tests
//
//  Created by Tanya Atrvash on 9/17/24.
//

import Testing
@testable import Atrvash_Tanya_HW2

struct Atrvash_Tanya_HW2Tests {

    @Test func example() async throws {
        // Write your test here and use APIs like `#expect(...)` to check expected conditions.
    }

}
