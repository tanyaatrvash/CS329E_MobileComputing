//
//  CircleImage.swift
//  CD-SwiftUITurtleRock
//
//  Created by Tanya Atrvash on 11/20/24.
//

import SwiftUI

struct CircleImage: View {
    var body: some View {
        Image("turtlerock")
            .clipShape(Circle())
            .overlay(
                Circle()
                    .stroke(Color.white, lineWidth: 4)
                    .shadow(radius: 10)
            )
    }
}
