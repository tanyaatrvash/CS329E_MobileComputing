//
//  CD_SwiftUITurtleRockApp.swift
//  CD-SwiftUITurtleRock
//
//  Created by Tanya Atrvash on 11/20/24.
//

import SwiftUI

@main
struct CD_SwiftUITurtleRockApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
