// Project: AtrvashTanya-HW4
// EID: tka435
// Course: CS329E

//  ViewController.swift
//  AtrvashTanya-HW4
//
//  Created by Tanya Atrvash on 10/4/24.
//

import UIKit

class ViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {

    @IBOutlet weak var tableView: UITableView!
    
    let operations = ["Add", "Subtract", "Multiply", "Divide"]
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        tableView.delegate = self
        tableView.dataSource = self
    }

    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return operations.count // return number of operations
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "operationCell", for: indexPath)
        cell.textLabel?.text = operations[indexPath.row]  // set operation text
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
            // segue when operation is selected
            performSegue(withIdentifier: "calcVCSeg", sender: operations[indexPath.row])
        }

        // prepare segue to pass selected operation to CalcViewController
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "calcVCSeg" {
            if let destinationVC = segue.destination as? CalcViewController {
                destinationVC.selectedOperation = sender as? String  // pass operation
            }
        }
    }

}

