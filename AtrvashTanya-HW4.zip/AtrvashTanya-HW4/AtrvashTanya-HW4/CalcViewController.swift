// Project: AtrvashTanya-HW4
// EID: tka435
// Course: CS329E

//  CalcViewController.swift
//  AtrvashTanya-HW4
//
//  Created by Tanya Atrvash on 10/4/24.
//

import UIKit

class CalcViewController: UIViewController {
    
    @IBOutlet weak var textFieldOP1: UITextField!
    @IBOutlet weak var textFieldOP2: UITextField!
    @IBOutlet weak var operatorLabel: UILabel!
    @IBOutlet weak var resultLabel: UILabel!
    
    var selectedOperation: String?  // operation passed from TableView
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        // update operator label based on the selected operation
        switch selectedOperation {
        case "Add":
            operatorLabel.text = "+"
        case "Subtract":
            operatorLabel.text = "-"
        case "Multiply":
            operatorLabel.text = "*"
        case "Divide":
            operatorLabel.text = "/"
        default:
            operatorLabel.text = ""
        }
    }
    
    
    @IBAction func resultButtonPressed(_ sender: Any) {
        // get text input from the two text fields
        guard let operand1Text = textFieldOP1.text,
              let operand2Text = textFieldOP2.text else { return }
        
        // operands as integers
        if let operand1Int = Int(operand1Text), let operand2Int = Int(operand2Text) {
            var resultInt: Int = 0
            
            // integer operation
            switch selectedOperation {
            case "Add":
                resultInt = operand1Int + operand2Int
            case "Subtract":
                resultInt = operand1Int - operand2Int
            case "Multiply":
                resultInt = operand1Int * operand2Int
            case "Divide":
                if operand2Int != 0 {
                    resultInt = operand1Int / operand2Int
                } else {
                    resultLabel.text = "Error: Divide by 0"
                    return
                }
            default:
                resultLabel.text = "Error"
                return
            }
            
            // int result
            resultLabel.text = String(resultInt)
            
        } else if let operand1Float = Float(operand1Text), let operand2Float = Float(operand2Text) {
            var resultFloat: Float = 0
            
            // float operation
            switch selectedOperation {
            case "Add":
                resultFloat = operand1Float + operand2Float
            case "Subtract":
                resultFloat = operand1Float - operand2Float
            case "Multiply":
                resultFloat = operand1Float * operand2Float
            case "Divide":
                if operand2Float != 0 {
                    resultFloat = operand1Float / operand2Float
                } else {
                    resultLabel.text = "Error: Divide by 0"
                    return
                }
            default:
                resultLabel.text = "Error"
                return
            }
            
            // float result
            resultLabel.text = String(resultFloat)
        } else {
            resultLabel.text = "Error: Invalid input"
        }
    }
}
