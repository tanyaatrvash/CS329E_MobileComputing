//
//  ViewController.swift
//  CD-StackViews
//
//  Created by Tanya Atrvash on 10/30/24.
//

import UIKit

class ViewController: UIViewController {
    
    
    @IBOutlet weak var label: UILabel!
    @IBOutlet weak var imageView: UIImageView!
    
    var imageCount = 6          // num of total images
    var current = 0             // current image displayed
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        showImage(index: 0)
    }
    
    func showImage(index:Int) {
        label.text = "Image \(index)"
        imageView.image = UIImage(named: "image\(index)")
    }

    @IBAction func onPreviousButtonPressed(_ sender: Any) {
        current = (current + imageCount - 1) % imageCount
        showImage(index: current)
    }
    
    @IBAction func onResetButtonPressed(_ sender: Any) {
        showImage(index: 0)
        current = 0
    }
    
    @IBAction func onNextButtonPressed(_ sender: Any) {
        current = (current + 1) % imageCount
        showImage(index: current)
    }
    
}

