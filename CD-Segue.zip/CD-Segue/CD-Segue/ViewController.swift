//
//  ViewController.swift
//  CD-Segue
//
//  Created by Tanya Atrvash on 9/18/24.
//

import UIKit

protocol TextChanger{
    func changeText(newName: String)
}

class ViewController: UIViewController, TextChanger {

    @IBOutlet weak var nameField1: UILabel!
    @IBOutlet weak var textField1: UITextField!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        
        nameField1.text = "undefined"
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "SegueIdentifier",
           let nextVC = segue.destination as? SecondViewController {
            nextVC.delegate = self
            nextVC.vc2NewName = textField1.text!
        }
        
    }
    
    func changeText(newName:String){
        nameField1.text = newName
    }

}

