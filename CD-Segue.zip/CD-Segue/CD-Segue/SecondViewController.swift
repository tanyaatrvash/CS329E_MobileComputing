//
//  SecondViewController.swift
//  CD-Segue
//
//  Created by Tanya Atrvash on 9/18/24.
//

import UIKit

class SecondViewController: UIViewController {

    @IBOutlet weak var textField2: UITextField!
    @IBOutlet weak var nameField2: UILabel!
    
    var delegate: UIViewController!
    var vc2NewName = ""
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        nameField2.text = vc2NewName
    }
    

    @IBAction func button2Pressed(_ sender: Any) {
        let otherVC = delegate as! TextChanger // points to VC1 and changes VC1 name to this new name
        otherVC.changeText(newName:textField2.text!)
        self.dismiss(animated: true)
    }
    
}
