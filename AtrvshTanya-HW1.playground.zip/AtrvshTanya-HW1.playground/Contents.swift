// Project: AtrvashTanya-HW1
// EID: tka435
// Course: CS329E

// weapon class representing weapon types and their damage values
class Weapon {
    let weaponType: String
    let damage: Int // damage value of weapon
    
    init(weaponType: String) {
        self.weaponType = weaponType
        switch weaponType {
        case "dagger":
            self.damage = 4
        case "axe", "staff":
            self.damage = 6
        case "sword":
            self.damage = 10
        case "none":
            self.damage = 1
        default:
            self.damage = 1
        }
    }
}


// armor class representing armor types and their armor class
class Armor {
    let armorType: String
    let armorClass: Int // armor class value (lower = better)
    
    init(armorType: String) {
        self.armorType = armorType
        switch armorType {
        case "plate":
            self.armorClass = 2
        case "chain":
            self.armorClass = 5
        case "leather":
            self.armorClass = 8
        case "none":
            self.armorClass = 10
        default:
            self.armorClass = 10
        }
    }
}

// base character class with health, spell points, weapons, armor
class RPGCharacter {
    let name: String
    var currentHealth: Int
    var maxHealth: Int
    var currentSpellPoints: Int
    var maxSpellPoints: Int
    var weapon: Weapon = Weapon(weaponType: "none") // weapon character is wielding
    var armor: Armor = Armor(armorType: "none") // armor character is wearing
    
    // allowed weapons for this character class, overridden by subclasses
    var allowedWeapons: [String] {
            return []
        }
    
    // setting up character attributes/stats
    init(name: String, maxHealth: Int, maxSpellPoints: Int) {
        self.name = name
        self.maxHealth = maxHealth
        self.currentHealth = maxHealth
        self.maxSpellPoints = maxSpellPoints
        self.currentSpellPoints = maxSpellPoints
    }
    
    // displays character stats
    func show() {
        print("\(name)\n    Current Health: \(currentHealth)\n    Current Spell Points: \(currentSpellPoints)\n    Wielding: \(weapon.weaponType)\n    Wearing: \(armor.armorType)\n    Armor Class: \(armor.armorClass)")
    }
    
    // checks for character type, allows weapon to wield for character type
    func wield(weaponObject: Weapon) {
            if allowedWeapons.contains(weaponObject.weaponType) {
                self.weapon = weaponObject
                print("\(name) is now wielding a(n) \(weapon.weaponType)")
            } else {
                print("Weapon not allowed for this character class.")
            }
        }
    
    func unwield() {
        self.weapon = Weapon(weaponType: "none")
        print("\(name) is no longer wielding anything.")
    }
    
    func putOnArmor(armorObject: Armor) {
        self.armor = armorObject
        print("\(name) is now wearing \(armor.armorType)")
    }
    
    func takeOffArmor() {
        self.armor = Armor(armorType: "none")
        print("\(name) is no longer wearing any armor.")
    }
    
    // simulates fight between characters and deals weapon damage
    func fight(opponent: RPGCharacter) {
        print("\(name) attacks \(opponent.name) with a(n) \(weapon.weaponType)")
        // damage is directly from the weapon's damage value (does not take into account armor)
        let finalDamage = weapon.damage

        // apply damage to opponent's health
        opponent.currentHealth -= finalDamage
        print("\(name) does \(finalDamage) damage to \(opponent.name)")
        print("\(opponent.name) is now down to \(opponent.currentHealth) health")
        checkForDefeat(character: opponent)
    }
    
    // checks if a character has been defeated (health <= 0)
    func checkForDefeat(character: RPGCharacter) {
        if character.currentHealth <= 0 {
            print("\(character.name) has been defeated!")
        }
    }
}

// fighter subclass specialized in combat and specific weapons
class Fighter: RPGCharacter {
    override var allowedWeapons: [String] {
        return ["sword", "axe", "dagger"]
    }
    
    init(name: String) {
        super.init(name: name, maxHealth: 40, maxSpellPoints: 0)
    }
}

// wizard subclass specialized in spells and magic
class Wizard: RPGCharacter {
    override var allowedWeapons: [String] {
        return ["staff", "dagger"]
    }
    
    init(name: String) {
        super.init(name: name, maxHealth: 16, maxSpellPoints: 20)
    }
    
    // casts a spell on a target, checking for valid spells and spell points
    func castSpell(spellName: String, target: RPGCharacter) {
        let spells = ["Fireball": (cost: 3, effect: 5), "Lightning Bolt": (cost: 10, effect: 10), "Heal": (cost: 6, effect: -6)]
        
        // check for valid spell
        guard let spell = spells[spellName] else {
            print("Unknown spell name. Spell failed.")
            return
        }
        
        // check for sufficient spell points to cast a spell
        if currentSpellPoints < spell.cost {
            print("Insufficient spell points")
            return
        }
        
        // deduct spell points from caster
        currentSpellPoints -= spell.cost
        
        // adjust target health based on spell effect (healing or damage)
        if spellName == "Heal" {
            let healAmount = min(-spell.effect, target.maxHealth - target.currentHealth)
            target.currentHealth += healAmount
            print("\(name) casts \(spellName) at \(target.name)")
            print("\(name) heals \(target.name) for \(healAmount) health points")
            print("\(target.name) is now at \(target.currentHealth) health")
        } else {
            target.currentHealth -= spell.effect
            print("\(name) casts \(spellName) at \(target.name)")
            print("\(name) does \(spell.effect) damage to \(target.name)")
            print("\(target.name) is now down to \(target.currentHealth) health")
        }
        
        // check if target is defeated
        checkForDefeat(character: target)
    }
}

// top level code
let plateMail = Armor(armorType: "plate")
let chainMail = Armor(armorType: "chain")
let sword = Weapon(weaponType: "sword")
let staff = Weapon(weaponType: "staff")
let axe = Weapon(weaponType: "axe")
let gandalf = Wizard(name: "Gandalf the Grey")

gandalf.wield(weaponObject: staff)

let aragorn = Fighter(name: "Aragorn")

aragorn.putOnArmor(armorObject: plateMail)

aragorn.wield(weaponObject: axe)

gandalf.show()

aragorn.show()

gandalf.castSpell(spellName: "Fireball", target: aragorn)

aragorn.fight(opponent: gandalf)

gandalf.show()

aragorn.show()

gandalf.castSpell(spellName: "Lightning Bolt", target: aragorn)

aragorn.wield(weaponObject: sword)

gandalf.show()

aragorn.show()

gandalf.castSpell(spellName: "Heal", target: gandalf)

aragorn.fight(opponent: gandalf)

gandalf.fight(opponent: aragorn)

aragorn.fight(opponent: gandalf)

gandalf.show()

aragorn.show()
