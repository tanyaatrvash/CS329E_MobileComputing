//
//  AtrvashTanya_HW10App.swift
//  AtrvashTanya-HW10
//
//  Created by Tanya Atrvash on 11/30/24.
//

import SwiftUI

@main
struct AtrvashTanya_HW10App: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
