// Project: AtrvashTanya-HW2
// EID: tka435
// Course: CS329E

//  ContentView.swift
//  AtrvashTanya-HW10
//
//  Created by Tanya Atrvash on 11/30/24.
//

import SwiftUI

struct ContentView: View {
    @State private var userID: String = ""
    @State private var password: String = ""
    @State private var statusMessage: String = "Not currently logged in"
    
    var body: some View {
        VStack(spacing: 30) {
            Text("User Login")
                .frame(maxWidth: .infinity)
                .multilineTextAlignment(.center)
            
            HStack {
                Text("userID:")
                    .frame(width: 100, alignment: .trailing)
                
                TextField("Enter userID", text: $userID)
                    .textFieldStyle(RoundedBorderTextFieldStyle())
                    .frame(width: 250)
            }
            
            HStack {
                Text("Password:")
                    .frame(width: 100, alignment: .trailing)
                
                SecureField("Enter password", text: $password)
                    .textFieldStyle(RoundedBorderTextFieldStyle())
                    .frame(width: 250)
            }
            
            Button(action: buttonPressed) {
                Text("Login")
                    .frame(width: 250)
                    .padding()
                    .background(Color.white)
                    .foregroundColor(.blue)
                    .cornerRadius(10)
            }
            
            Text(statusMessage)
                .frame(width: 250)
                .multilineTextAlignment(.center)
        }
        .padding()
        // dismiss keyboard when tapping outside
        .onTapGesture {
            UIApplication.shared.sendAction(#selector(UIResponder.resignFirstResponder), to: nil, from: nil, for: nil)
        }
    }
    
    func buttonPressed() {
        if userID.isEmpty || password.isEmpty {
            statusMessage = "Invalid login"
        } else {
            statusMessage = "\(userID) logged in"
        }
    }
}

#Preview {
    ContentView()
}
