// Project: AtrvashTanya-HW8
// EID: tka435
// Course: CS329E

//  ViewController.swift
//  AtrvashTanya-HW8
//
//  Created by Tanya Atrvash on 11/10/24.
//

import UIKit
import UserNotifications

class ViewController: UIViewController {
    
    @IBOutlet weak var imageButton: UIButton!
    
    var clickCount = 0
    var isShowingTower = true

    override func viewDidLoad() {
        super.viewDidLoad()
        
        requestNotificationPermission()
    }
    
    func requestNotificationPermission() {
        UNUserNotificationCenter.current().requestAuthorization(options: [.alert, .sound, .badge]) { granted, error in
            if granted {
                print("Notification permission granted")
            } else if let error = error {
                print("Error requesting notification permission: \(error.localizedDescription)")
            }
        }
    }
    
    func scheduleNotification() {
        let content = UNMutableNotificationContent()
        content.title = "Click Count"
        content.subtitle = "Keep clicking to see more animations!"
        content.body = "You have clicked \(clickCount) times"
        
        let trigger = UNTimeIntervalNotificationTrigger(timeInterval: 8, repeats: false)
        
        let request = UNNotificationRequest(identifier: UUID().uuidString,
                                          content: content,
                                          trigger: trigger)
        
        UNUserNotificationCenter.current().add(request) { error in
            if let error = error {
                print("Error scheduling notification: \(error.localizedDescription)")
            }
        }
    }


    @IBAction func imageButtonPressed(_ sender: Any) {
        clickCount += 1
        
        UIView.animate(withDuration: 1.0,
                      delay: 0.0,
                      options: .curveEaseOut,
                      animations: { [weak self] in
            self?.imageButton.alpha = 0.0
        }) { [weak self] _ in
            self?.isShowingTower.toggle()
            let newImage = self?.isShowingTower ?? false ? "uttower" : "ut"
            self?.imageButton.setImage(UIImage(named: newImage), for: .normal)
            
            UIView.animate(withDuration: 1.0,
                          delay: 0.0,
                          options: .curveEaseIn,
                          animations: { [weak self] in
                self?.imageButton.alpha = 1.0
            })
        }
        
        if clickCount % 4 == 0 {
            scheduleNotification()
            UIControl().sendAction(#selector(URLSessionTask.suspend),
                                 to: UIApplication.shared,
                                 for: nil)
        }
    }
}

